
ALTER TABLE `payment_transaction_item` CHANGE `slug` `slug` VARCHAR( 100 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL ;
ALTER TABLE `payment_shopping_cart` CHANGE `slug` `slug` VARCHAR( 100 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL ;
