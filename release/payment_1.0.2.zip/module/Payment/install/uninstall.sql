DROP TABLE IF EXISTS `payment_transaction_item`;
DROP TABLE IF EXISTS `payment_shopping_cart`;
DROP TABLE IF EXISTS `payment_module`;
DROP TABLE IF EXISTS `payment_exchange_rate`;
DROP TABLE IF EXISTS `payment_transaction_list`;
DROP TABLE IF EXISTS `payment_currency`;
DROP TABLE IF EXISTS `payment_type`;
DROP TABLE IF EXISTS `payment_discount_coupon`;