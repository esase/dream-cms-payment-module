<?php 

return [
	'module_path' => 'module/Payment',
    'layout_path' => 'layout/payment'
];
