<?php

namespace Payment\Exception;
use Exception;

class PaymentException extends Exception
{}